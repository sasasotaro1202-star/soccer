import os, subprocess, sys
limit=int(os.getenv("RUNTIME_LIMIT_SECONDS","1680"))
env=os.environ.copy(); env["RUNTIME_LIMIT_SECONDS"]=str(limit)
p=subprocess.Popen([sys.executable,"backtest.py"],env=env)
try: rc=p.wait(timeout=limit+30)
except subprocess.TimeoutExpired:
    p.terminate()
    try: rc=p.wait(timeout=20)
    except subprocess.TimeoutExpired: p.kill(); rc=p.wait()
    print("Safety stop; checkpoint will be used next run."); raise SystemExit(0)
raise SystemExit(rc)
