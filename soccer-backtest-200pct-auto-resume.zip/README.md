# Soccer Backtest Max Auto Resume
- 1回約28分で安全停止
- checkpointをGitへ自動保存
- 次回Runで未完了部分から再開
- Football-Dataキャッシュと既存checkpointを同梱
- 現行最終モデルをベースに継続可能
- 精度200%は文字通りの保証ではなく、検証品質・データ品質・再現性・運用完成度を最大化する目標
